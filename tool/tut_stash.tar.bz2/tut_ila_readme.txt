The following files were generated for 'tut_ila' in directory
/home/cc/cs199/fa12/class/cs199-fu/team45/hardware/src/mig_xupv5/scooper/

XCO file generator:
   Generate an XCO file for compatibility with legacy flows.

   * tut_ila.xco

Creates an implementation netlist:
   Creates an implementation netlist for the IP.

   * tut_ila.cdc
   * tut_ila.ngc
   * tut_ila.v
   * tut_ila.veo

Creates an HDL instantiation template:
   Creates an HDL instantiation template for the IP.

   * tut_ila.veo

IP Symbol Generator:
   Generate an IP symbol based on the current project options'.

   * tut_ila.asy

Generate ISE metadata:
   Create a metadata file for use when including this core in ISE designs

   * tut_ila_xmdf.tcl

Generate ISE subproject:
   Create an ISE subproject for use when including this core in ISE designs

   * tut_ila.gise
   * tut_ila.xise

Deliver Readme:
   Readme file for the IP.

   * tut_ila_readme.txt

Generate FLIST file:
   Text file listing all of the output files produced when a customized core was
   generated in the CORE Generator.

   * tut_ila_flist.txt

Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

