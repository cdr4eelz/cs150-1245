The following files were generated for 'tut_icon' in directory
/home/cc/cs199/fa12/class/cs199-fu/team45/hardware/src/mig_xupv5/scooper/

XCO file generator:
   Generate an XCO file for compatibility with legacy flows.

   * tut_icon.xco

Creates an implementation netlist:
   Creates an implementation netlist for the IP.

   * tut_icon.ngc
   * tut_icon.v
   * tut_icon.veo

Creates an HDL instantiation template:
   Creates an HDL instantiation template for the IP.

   * tut_icon.veo

IP Symbol Generator:
   Generate an IP symbol based on the current project options'.

   * tut_icon.asy

Generate ISE metadata:
   Create a metadata file for use when including this core in ISE designs

   * tut_icon_xmdf.tcl

Generate ISE subproject:
   Create an ISE subproject for use when including this core in ISE designs

   * tut_icon.gise
   * tut_icon.xise

Deliver Readme:
   Readme file for the IP.

   * tut_icon_readme.txt

Generate FLIST file:
   Text file listing all of the output files produced when a customized core was
   generated in the CORE Generator.

   * tut_icon_flist.txt

Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

